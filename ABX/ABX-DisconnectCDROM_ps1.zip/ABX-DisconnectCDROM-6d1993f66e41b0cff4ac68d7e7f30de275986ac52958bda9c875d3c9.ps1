function handler($context, $inputs) {
    
    $vmName = $inputs.resourceNames[0]
    $vcFqdn = $inputs.vcFQDN
    $vcUser = $inputs.vcUSER
    $vcPwd   = $context.getSecret($inputs.vcPWD)
    
    Connect-VIServer -Server $vcFqdn -User $vcUser -Password $vcPwd -Protocol https -Force
    
    # Disconnect media from all CD-ROMs
    $objVM = Get-VM -Name $vmName
    $arrCDROMs = Get-CDDrive -VM $objVM
    Foreach ( $cd in $arrCDROMs ) {
        Set-CDDrive -CD $cd -NoMedia -Confirm:$false 
    }

    Disconnect-VIServer * -Confirm:$false
}
