# https://developer.vmware.com/samples/7689/abx-action-to-openssh-to-a-windows-server?h=vRealize%20Automation#code

def handler(context, inputs):
    import paramiko
    
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    # set variables
    #target_server = "192.168.30.43"
    target_server = context.getSecret(inputs["fileRepoIP"])
    Username = "root"
    Password = context.getSecret(inputs["rootPWD"])
    statuscode = 200

    # Command to run on the target
    #exec_command = "ls -l /"
    exec_command = "bash /tmp/test.sh"
    
    # Connect to target using username/password authentication.
    ssh.connect(hostname=target_server, username=Username, password=Password, look_for_keys=False)
    
    # Run command.
    (ssh_stdin, ssh_stdout, ssh_stderr) = ssh.exec_command(exec_command)
    output = ssh_stdout.readlines()             # Output is of type "list"
    
    # Close connection.
    ssh.close()

    ## Test return output
    # If list does NOT contains full string
    #string = "total 32\n"
    #if not string in output:
    #    statuscode = 404
    
    # If list contains a specific substring - part of
    substring = "total"
    indexs = []
    if not  any(substring in string for string in output):
        statuscode = 404
    else:
        indexs = [i for i, elem in enumerate(output) if 'tmp' in elem]
        
    outputs = {
        'output': output,
        'statuscode': statuscode,
        'indexes': indexs
    }
    
    print(outputs)
    
    return outputs
