<#
    Function filters through IP Ranges (vRA Internal IPAM) to find the passed fabric-network association
    Returns the first matching IPRange
    
    Default Inputs:
    - ipranges      # Type: Default     (passed from "/iaas/api/network-ip-ranges")
    - network       # Type: Default     (selected from "/iaas/api/fabric-networks")
    
    Output:
    - selfHREF      (self.href of selected IPRange)
    
    Tested on vRA 8.12.1
#>

function handler($context, $inputs) {
  
    $thisNetworks = $inputs.network
    $thisIPRanges = $inputs.ipranges
 
    $thisNetworkHref = $thisNetworks._links.self.href

    $thisIPRangeHref = ""
    foreach ( $ipRange in $thisIPRanges) {
        foreach ( $objFabricNetwork in $ipRange._links."fabric-networks".hrefs ) {
            if ( $objFabricNetwork -eq  $thisNetworkHref ) {
                $thisIPRangeHref = $ipRange._links.self.href
                #Write-Host $ipRange.name
                #Write-Host $thisIPRangeHref
                break
            }
        }
    }
    
    $outputs = @{
        selfHREF = $thisReturn
    }
    
    Write-Host ($outputs | Out-String)
    
    return $outputs
}
