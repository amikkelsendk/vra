def handler(context, inputs):
    output = inputs
    
    print(output)
    if inputs["customProperties"]["testPowerOn"] == "no":
        output['initialPowerOn'] = 'false'
    return output