function handler($context, $inputs) {
  
  return (get-module -ListAvailable | Out-String)
}
