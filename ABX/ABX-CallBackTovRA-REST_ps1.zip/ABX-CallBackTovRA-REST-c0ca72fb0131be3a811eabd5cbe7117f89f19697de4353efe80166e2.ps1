Function Get-vRARefreshToken {
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$vraServer,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$userName,
        
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$UnsecurePassword
    )

    $authBody   = @{
        "username" = $userName
        "password" = $UnsecurePassword
    }

    # Build Header:
    $header = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $header.Add("Accept","application/json")
    $header.Add("Content-Type","application/json")
    
    # Get Refresh Token:
    $uri                = "https://" + $vraServer + "/csp/gateway/am/api/login?access_token"
    $thisRefreshToken   = Invoke-RestMethod -uri $uri -Method POST -Headers $header -Body ($authBody | ConvertTo-Json) -SkipCertificateCheck
    
    Return $thisRefreshToken.refresh_token
}

Function Get-vRABearerToken {
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$vraServer,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$RefreshToken
    )
       
    # Build Header:
    $header = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $header.Add("Accept","application/json")
    $header.Add("Content-Type","application/json")
    
    # Build Body
    $refreshTokenBody = @{
        "refreshToken" = $RefreshToken
    }

    # Get Access Token:
    $uri            = "https://" + $vraServer + "/iaas/api/login"
    $accessToken    = Invoke-RestMethod -Uri $uri -Method POST -Headers $header -body ($refreshTokenBody | ConvertTo-JSON) -SkipCertificateCheck
    $accessToken    = "Bearer " + $accessToken.token
    
    Return $accessToken
}

Function handler($context, $inputs){
    $vraServer = $inputs.vraURL
    $userName  = $inputs.vraUser
    $userPWD   = $context.getSecret($inputs.vraPWD)

    # Get Tokens
    $refreshToken   = Get-vRARefreshToken -vraServer $vraServer -userName $userName -UnsecurePassword $userPWD
    $accessToken    = Get-vRABearerToken -vraServer $vraServer -RefreshToken $refreshToken
    
    # Build Header:
    $header = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $header.Add("Accept","application/json")
    $header.Add("Content-Type","application/json")
    $header.Add("Authorization",$accessToken)       # add access token to Header
    
    
    # Query API
    $uri        = "https://" + $vraServer + "/abx/api/resources/actions"
    $abxResult  = Invoke-WebRequest -uri $uri -Method GET -Headers $header -SkipCertificateCheck
    $arrABX     = ( $abxResult | ConvertFrom-Json ).Content

    Write-Host ($arrABX | Out-String)
    
    #return inputs
}