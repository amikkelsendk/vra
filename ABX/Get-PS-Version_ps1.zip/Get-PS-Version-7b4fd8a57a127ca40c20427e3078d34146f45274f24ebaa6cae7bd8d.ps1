function handler($context, $inputs) {

    Write-Host "PSVersion:    $($PSVersionTable.PSVersion.ToString())"
    Write-Host "BuildVersion: $($PSVersionTable.BuildVersion.ToString())"
    
}
