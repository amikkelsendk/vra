def handler(context, inputs):
    
    # FAIL
    exit(-1)
    
    # Completed OK
    exit(0)
