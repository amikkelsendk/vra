import requests
import time
import json
 
 
def handler(context, inputs):
    # Taking the value from secret into local Variable
 
    vrafqdn = context.getSecret(inputs['vRAURL'])
    username = context.getSecret(inputs['vRAUserName'])
    password = context.getSecret(inputs['vRAPAssword'])
    deploymentid = inputs['deploymentId']
 
 
    # Taking the value from secret into local Variable
 
    # grabbing  the latest API API Version
 
    api_version_url = f'https://{vrafqdn}/iaas/api/about'
    headers = {
        'accept': "application/json",
        'content-type': "application/json"
 
    }
    output = requests.get(url=api_version_url, headers=headers, verify=False)
    # grabbing  the latest API API Version
 
    if output.status_code == 200:
        latest_api_version = output.json()['latestApiVersion']
        apiversion = latest_api_version
        # Grabbing the token for authentication
        refreshtokenurl = f"https://{vrafqdn}/csp/gateway/am/api/login?access_token"
        iaasUrl = f"https://{vrafqdn}/iaas/api/login?apiVersion={apiversion}"
        headers = {
            'accept': "application/json",
            'content-type': "application/json"
 
        }
        payload = f'{{"username":"{username}","password":"{password}"}}'
        apioutput = requests.post(refreshtokenurl, data=payload, verify=False, headers=headers)
        refreshtoken = apioutput.json()['refresh_token']
        iaasPayload = f'{{"refreshToken": "{refreshtoken}"}}'
        iaasApiOutput = requests.post(iaasUrl, data=iaasPayload, headers=headers, verify=False).json()['token']
        bearerToken = "Bearer " + iaasApiOutput
        # Grabbing the token for authentication
 
        url = f'https://{vrafqdn}/deployment/api/deployments/{deploymentid}/requests'
        dheaders = {
            'accept': "application/json",
            'content-type': "application/json",
            'authorization': bearerToken
        }
         
        data = {
            "actionId": "Deployment.Delete"
        }
 
        apioutput2 = requests.post(url, headers=dheaders, data = json.dumps(data),verify=False)
        if apioutput2.status_code == 200:
            print('Failed Deployment has been removed')
        else:
            print(f'Deployment deletion failed with error {apioutput2.status_code}, Here is the reason \n')
            print(apioutput2.json())
         
 
 
 
 
    else:
        print(output.status_code)