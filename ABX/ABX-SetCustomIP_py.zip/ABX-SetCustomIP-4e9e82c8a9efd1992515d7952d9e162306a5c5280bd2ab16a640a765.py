# https://vmwarecode.com/2021/05/21/how-to-change-the-ip-address-and-rename-of-vm-in-vra-8/

# Sets a custom IP in a VM - does NOT update any IPAM (internal or external)
# Run as a Subscription
#   Event Topic:  Network Configure
#   Condition  :  Up to you, I used 'event.data.customProperties.setIP == "yes"'
#   Blocking   :  Yes
#


def handler(context, inputs):
    vmIP = inputs['customProperties']['setThisIP']
    
    outputs = {}
    addresses = [[]]
    outputs["addresses"] = addresses
    outputs["addresses"][0]=[str(vmIP)]
    
    return outputs