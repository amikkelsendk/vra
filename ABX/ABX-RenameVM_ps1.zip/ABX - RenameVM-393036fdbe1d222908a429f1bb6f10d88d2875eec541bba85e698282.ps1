function handler($context, $inputs) {
    <#
        .SYNOPSIS
        Sets a name for a machine

        .DESCRIPTION
        Sets or modify a name for a machine which is taken
        from the inputs of the Action.

        .PARAMETER inputs
        The inputs of the action with the current name of the machine,
        and the new name of the machine.

        .OUTPUTS
        The outputs of the action with the new name of the machine.
    #>

    $oldName = $inputs.resourceNames[0]
    $newName = $inputs.customProperties.newName

    $outputs = @{
        resourceNames = $inputs.resourceNames
    }

    $outputs.resourceNames[0] = $newName

    Write-Host "Setting machine name from " $oldName " to " $newName

    return $outputs
}
