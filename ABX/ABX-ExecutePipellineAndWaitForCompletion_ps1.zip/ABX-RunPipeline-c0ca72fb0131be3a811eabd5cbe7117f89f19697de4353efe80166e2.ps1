Function Get-vRARefreshToken {
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$vraServer,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$userName,
        
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$UnsecurePassword
    )

    $authBody   = @{
        "username" = $userName
        "password" = $UnsecurePassword
    }

    # Build Header:
    $header = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $header.Add("Accept","application/json")
    $header.Add("Content-Type","application/json")
    
    # Get Refresh Token:
    $uri                = "https://" + $vraServer + "/csp/gateway/am/api/login?access_token"
    $thisRefreshToken   = Invoke-RestMethod -uri $uri -Method POST -Headers $header -Body ($authBody | ConvertTo-Json) -SkipCertificateCheck
    
    Return $thisRefreshToken.refresh_token
}

Function Get-vRABearerToken {
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$vraServer,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$RefreshToken
    )
       
    # Build Header:
    $header = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $header.Add("Accept","application/json")
    $header.Add("Content-Type","application/json")
    
    # Build Body
    $refreshTokenBody = @{
        "refreshToken" = $RefreshToken
    }

    # Get Access Token:
    $uri            = "https://" + $vraServer + "/iaas/api/login"
    $accessToken    = Invoke-RestMethod -Uri $uri -Method POST -Headers $header -body ($refreshTokenBody | ConvertTo-JSON) -SkipCertificateCheck
    $accessToken    = "Bearer " + $accessToken.token
    
    Return $accessToken
}

Function handler($context, $inputs){
    $vraServer          = $inputs.vraURL
    $userName           = $inputs.vraUser
    $userPWD            = $context.getSecret($inputs.vraPWD)
    #$customProperties   = $inputs.customProperties


    # Default returns
    $exitCode     = 200
    $errorMessage = "OK"


    # Generate Tokens
    Try {
        # Get Tokens
        $refreshToken   = Get-vRARefreshToken -vraServer $vraServer -userName $userName -UnsecurePassword $userPWD
        $accessToken    = Get-vRABearerToken -vraServer $vraServer -RefreshToken $refreshToken
    }
    Catch {
        Write-Host "Error generating tokens"
        $exitCode     = 400
        $errorMessage = ( $_.Exception.Message | Out-String )
    }


    # Execute Pipeline
    If ( $exitCode -eq 200 ) {
        Try {
            # Build Header:
            $header = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
            $header.Add("Accept","application/json")
            $header.Add("Content-Type","application/json")
            $header.Add("Authorization",$accessToken)       # add access token to Header
        
            # Build Payload
            #https://medium.com/@semeltheone_87908/how-to-create-json-in-powershell-893388280185
            <#
            $payload = @{
                comments = "Executed from ABX via API"
                input    = @{
                    hostname  = $inputs.resourceNames[0]
                    flavor    = $customProperties.flavor
                    image     = $customProperties.image
                }
            }
            #>

            $payload = @{
                comments = "Executed from ABX via API"
                input    = @{
                    hostname  = "test001"
                    flavor    = "large"
                    image     = "win"
                }
            }

            Write-Host "Payload:`n"
            Write-Host ( $payload | ConvertTo-Json )

            # Execute API call
            $uri        = "https://" + $vraServer + "/codestream/api/pipelines/8073846b-bb16-4f8c-812c-e22dceff7d73/executions"
            $pipelineResult  = Invoke-WebRequest -uri $uri -Method POST -Headers $header -Body ( $payload | ConvertTo-Json ) -SkipCertificateCheck

            Write-Host "Result:`n"
            Write-Host ( $pipelineResult | Out-String )

            $exitCode = $pipelineResult.StatusCode
        }
        Catch {
            Write-Host "Error executing pipeline"
            $exitCode     = 400
            $errorMessage = ( $_.Exception.Message | Out-String )
        }
    }


    # Verify API call  
    If ( $exitCode -eq 202 ) { 
        $exitCode = $pipelineResult.StatusCode
        $result   = ( $pipelineResult | ConvertFrom-Json )

        # Wait for pipeline execution to finish
        $maxRetries = 20
        $uri = "https://" + $vraServer + $result.executionLink
        Do {
            Start-Sleep -Seconds 10
            $maxRetries --
            $pipelineExecutionResult = Invoke-WebRequest -uri $uri -Method GET -Headers $header -SkipCertificateCheck

            If ( $pipelineExecutionResult.StatusCode -eq 200 ) {
                $waitResult = $pipelineExecutionResult.Content | ConvertFrom-Json
            }
            Else {
                Write-Host "Retires Remaining: $maxRetries"
                Write-Host "  ErrorCode: $pipelineExecutionResult.StatusCode"
            }
        }
        Until ( $waitResult.status -eq "COMPLETED" -or $maxRetries -le 0 )

        Write-Host "Result:`n"
        Write-Host ( $pipelineExecutionResult | Out-String )

        If ( $waitResult.status -eq "COMPLETED" ) {
            $exitCode = 200
        }
        Else {
            $exitCode     = 400
            $errorMessage = "Pipeline execution status not as expected. Expected 'COMPLETED', but returned '$( $waitResult.status )'"
            Write-Host "Error: $errorMessage"
        }
    }
    Else {
        $exitCode     = 400
        $errorMessage = "Pipeline statuscode not as expected. Expected 202, but returned $( $pipelineResult.StatusCode )"
        Write-Host "Error: $errorMessage"
    }
    
    
    # Build output
    $outputs = @{
        exitCode     = $exitCode
        errorMessage = $errorMessage
    }
    
    
    # Return or Throw error/Exit with error
    If ( $exitCode -eq 200 ) {
        return $outputs
    }
    Else {
        Exit -1   
    }
}