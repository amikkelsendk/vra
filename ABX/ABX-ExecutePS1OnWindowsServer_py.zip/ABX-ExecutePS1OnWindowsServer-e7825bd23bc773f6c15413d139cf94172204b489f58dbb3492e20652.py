# https://developer.vmware.com/samples/7689/abx-action-to-openssh-to-a-windows-server?h=vRealize%20Automation#code

def handler(context, inputs):
    import paramiko
    
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    ## Set variables ##
    target_server = inputs["targetServer"]
    username = inputs["WinSSHUser"]
    password = context.getSecret(inputs["WinSSHPWD"])
    statuscode = 200
    new_line = '\n'

    
    ## Logic ##
    # Command to run on the target
    #exec_command = f'powershell.exe -command "pwd"'
    #exec_command = f'powershell.exe -command "(Get-WMIObject win32_operatingsystem) | Select Version"'
    exec_command = f'powershell.exe -command "& C:\Scripts\script1.ps1"'
    #exec_command = f'powershell.exe -command "& C:\Scripts\script2.ps1 -user {username}"'

    # Connect to target using username/password authentication.
    ssh.connect(hostname=target_server, username=username, password=password, look_for_keys=False)
    
    # Run command.
    (ssh_stdin, ssh_stdout, ssh_stderr) = ssh.exec_command(exec_command)
    output = ssh_stdout.readlines()             # Output is of type "list"
    
    # Close connection.
    ssh.close()
    
    # Get 'exec_command' returned statuscode
    print(output)
    
    # If error
    if statuscode != 200:
        errorText = f"ERROR!!!{new_line}Statuscode: {statuscode}\n{'{new_line}'.join(output)}"
        print (errorText)
        raise ValueError(errorText)
    
    # Return
    outputs = {
        'output': output,
        'statuscode': statuscode
    }
    
    return outputs
