function handler($context, $inputs) {
    
    $vmName = $inputs.resourceNames[0]
    $vcFqdn = $inputs.vcFQDN
    $vcUser = $inputs.vcUSER
    $vcPwd   = $context.getSecret($inputs.vcPWD)
    
    Connect-VIServer -Server $vcFqdn -User $vcUser -Password $vcPwd -Protocol https -Force
    
    $objVM = Get-VM -Name $vmName
    Stop-VMGuest -VM $objVM -Confirm:$false
    Start-Sleep -Seconds 30
    
    # Remove ALL CD-ROM drives from VM
    $objVM = Get-VM -Name $vmName
    $arrCDROMs = Get-CDDrive -VM $objVM
    Foreach ( $cd in $arrCDROMs ) {
        Remove-CDDrive -CD $cd -Confirm:$false
    }
    Start-Sleep -Seconds 10
    
    Start-VM $objVM 
    
    Disconnect-VIServer * -Confirm:$false
}

