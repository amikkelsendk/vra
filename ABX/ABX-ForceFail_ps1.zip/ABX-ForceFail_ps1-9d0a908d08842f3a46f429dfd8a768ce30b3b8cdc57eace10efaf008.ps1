function handler($context, $inputs) {
    # Both options works
  Write-Host "1"
  Exit -1
  
  Write-Host "2"
  Throw " Error"
}
